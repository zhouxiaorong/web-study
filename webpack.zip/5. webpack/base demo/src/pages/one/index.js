import one from './js/one'
import './css/one.css'

document.write('index');
one();