
export default function () {
  document.write('<p>add-content</p>')
}