
document.write("<h2>hello world index</h2>")