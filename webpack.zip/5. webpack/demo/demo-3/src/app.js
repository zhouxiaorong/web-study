
import { a } from './vendor/util'
console.log(a());