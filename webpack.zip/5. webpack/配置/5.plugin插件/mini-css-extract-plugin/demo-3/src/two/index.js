import "./index.css"

document.write('hello world two')