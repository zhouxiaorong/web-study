import "./index.css"

document.write('hello world one')