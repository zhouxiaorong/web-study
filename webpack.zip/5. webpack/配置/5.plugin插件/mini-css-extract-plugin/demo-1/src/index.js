import './index.css';
require('./style.css')

document.body.innerHTML =  `
  <h1>Hello World</h1>
  <p>hello world</p>
`;