
const index2 = require('./index2.js')

document.write('<h2>hello world one</h2>')
index2();