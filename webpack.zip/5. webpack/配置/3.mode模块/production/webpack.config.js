
module.exports = {
  mode: 'production'
}