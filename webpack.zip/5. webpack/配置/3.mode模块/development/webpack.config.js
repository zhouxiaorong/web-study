
module.exports = {
  mode: 'development'
}