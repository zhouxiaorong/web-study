
document.write('<h2>hello world index2</h2>')