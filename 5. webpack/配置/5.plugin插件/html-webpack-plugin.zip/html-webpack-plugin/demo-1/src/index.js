

document.write('hello world')