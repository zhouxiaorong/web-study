
document.write('hello world')