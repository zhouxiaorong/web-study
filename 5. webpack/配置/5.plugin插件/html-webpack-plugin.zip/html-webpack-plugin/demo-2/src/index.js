

document.write('<h1>hello world index</h1>')